package com.example.kledinghelper.viewmodel

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.kledinghelper.api.WeatherApi
import com.example.kledinghelper.data.WeatherResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface WeatherUiState {
    data class Success(val weather: WeatherResponse) : WeatherUiState
    data class Error(val message: String?) : WeatherUiState
    object Loading : WeatherUiState
}

class WeatherViewModel(application: Application) : AndroidViewModel(application) {
    var weatherUiState: WeatherUiState by mutableStateOf(WeatherUiState.Loading)
        private set

    private val sharedPreferences = application.getSharedPreferences("WeatherAppPrefs", Context.MODE_PRIVATE)

    private val _city = MutableStateFlow(sharedPreferences.getString("saved_city", "Eindhoven") ?: "Eindhoven")
    val city: StateFlow<String> = _city.asStateFlow()

    init { fetchWeather(_city.value) }

    // Publiek: altijd ophalen, geen check op gelijkheid
    fun updateCity(newCity: String) {
        if (newCity.isNotBlank()) fetchWeather(newCity)
    }

    private fun fetchWeather(city: String) {
        viewModelScope.launch {
            weatherUiState = WeatherUiState.Loading
            try {
                val result = WeatherApi.retrofitService.getCurrentWeather(city)
                weatherUiState = WeatherUiState.Success(result)
                _city.value = result.name   // gebruik officiële naam van API
                sharedPreferences.edit().putString("saved_city", result.name).apply()
            } catch (e: Exception) {
                weatherUiState = WeatherUiState.Error(e.message)
                // Stad terugzetten als API faalt
                _city.value = city
            }
        }
    }
}
