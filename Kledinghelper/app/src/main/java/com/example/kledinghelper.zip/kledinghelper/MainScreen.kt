package com.example.kledinghelper

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.kledinghelper.viewmodel.ClosetViewModel
import com.example.kledinghelper.viewmodel.WeatherUiState
import com.example.kledinghelper.viewmodel.WeatherViewModel
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    navController: NavController,
    weatherViewModel: WeatherViewModel,
    closetViewModel: ClosetViewModel
) {
    val recentItems by closetViewModel.recentItems.collectAsState()
    val outfits by closetViewModel.outfits.collectAsState()
    val uiState = weatherViewModel.weatherUiState
    
    // De donkere tekstkleur die overal gebruikt wordt (Purple40 in Theme.kt)
    val darkTextColor = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Weather Card
        when (uiState) {
            is WeatherUiState.Loading -> CircularProgressIndicator()
            is WeatherUiState.Success -> {
                val weatherData = uiState.weather
                val baseStyle = MaterialTheme.typography.headlineMedium.copy(color = Color.White)

                var textSizeRatio by remember(weatherData.name) { mutableStateOf(1f) }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF213961)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            Text(
                                text = weatherData.name,
                                style = baseStyle.copy(fontSize = baseStyle.fontSize * textSizeRatio),
                                maxLines = 1,
                                softWrap = false,
                                onTextLayout = { textLayoutResult ->
                                    if (textLayoutResult.hasVisualOverflow) {
                                        textSizeRatio *= 0.95f
                                    }
                                }
                            )
                        }
                        Spacer(modifier = Modifier.width(20.dp))
                        Text(
                            text = "${weatherData.main.temp.roundToInt()}°C",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White
                        )
                    }
                }
            }
            is WeatherUiState.Error -> Text("Failed to load weather data: ${uiState.message ?: "Unknown error"}")
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Outfits section
        if (outfits.isNotEmpty()) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Aanbevolen Outfits", 
                    style = MaterialTheme.typography.titleMedium,
                    color = darkTextColor
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    outfits.take(2).forEach { outfit ->
                        AsyncImage(
                            model = outfit.imagePath,
                            contentDescription = outfit.title,
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(0.8f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    navController.navigate(NavigationItem.OutfitDetail.createRoute(outfit.id.toString()))
                                },
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Recent Items Preview
        if (recentItems.isNotEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Kleding", 
                    style = MaterialTheme.typography.titleMedium,
                    color = darkTextColor
                )
                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.5f)
                        .aspectRatio(1f)
                        .clickable { navController.navigate(NavigationItem.Closet.route) }
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        userScrollEnabled = false,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(recentItems) { item ->
                            AsyncImage(
                                model = item.imagePath,
                                contentDescription = item.title,
                                modifier = Modifier
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }
        }
    }
}