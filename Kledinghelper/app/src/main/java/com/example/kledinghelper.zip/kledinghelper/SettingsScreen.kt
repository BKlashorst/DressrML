package com.example.kledinghelper

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.kledinghelper.viewmodel.WeatherViewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import java.util.Locale

@Composable
fun SettingsScreen(weatherViewModel: WeatherViewModel) {
    val currentCity by weatherViewModel.city.collectAsState()
    var textFieldValue by remember { mutableStateOf(currentCity) }
    val context = LocalContext.current

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            if (permissions.getOrDefault(Manifest.permission.ACCESS_FINE_LOCATION, false) ||
                permissions.getOrDefault(Manifest.permission.ACCESS_COARSE_LOCATION, false)) {
                getCurrentLocation(context) { cityName ->
                    textFieldValue = cityName
                    weatherViewModel.updateCity(cityName)
                }
            }
        }
    )

    // Update text field if the city in ViewModel changes from another source
    LaunchedEffect(currentCity) {
        textFieldValue = currentCity
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Voer een nieuwe locatie in:")

        OutlinedTextField(
            value = textFieldValue,
            onValueChange = { textFieldValue = it },
            label = { Text("Locatie") },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedTextColor = MaterialTheme.colorScheme.primary,
                unfocusedTextColor = MaterialTheme.colorScheme.primary,
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
            )
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { weatherViewModel.updateCity(textFieldValue) },
                colors = ButtonDefaults.buttonColors(contentColor = Color.White)
            ) {
                Text("Opslaan")
            }

            Button(
                onClick = {
                    // Check for permission and launch if needed
                    val permissionsToRequest = arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    if (permissionsToRequest.any { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }) {
                        locationPermissionLauncher.launch(permissionsToRequest)
                    } else {
                        getCurrentLocation(context) { cityName ->
                            textFieldValue = cityName
                            weatherViewModel.updateCity(cityName)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(contentColor = Color.White)
            ) {
                Text("Huidige Locatie")
            }
        }
    }
}

private fun getCurrentLocation(context: Context, onCityName: (String) -> Unit) {
    val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
        
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    try {
                        val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                        val cityName = addresses?.firstOrNull()?.locality ?: "Onbekend"
                        onCityName(cityName)
                    } catch (e: Exception) {
                        onCityName("Fout bij ophalen")
                    }
                }
            }
    }
}